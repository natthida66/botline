<?php
echo "Hello LINE BOT Im Ready Man!!";
